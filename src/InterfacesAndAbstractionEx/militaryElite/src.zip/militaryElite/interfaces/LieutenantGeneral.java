package militaryElite.interfaces;

public interface LieutenantGeneral {
    void addPrivates(Private priv);
}
