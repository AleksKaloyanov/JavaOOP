package militaryElite.interfaces;

import militaryElite.enums.Corp;

public interface SpecialisedSoldier {
    Corp getCorp();
}
